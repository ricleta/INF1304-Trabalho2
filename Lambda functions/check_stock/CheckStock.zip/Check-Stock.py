import json, boto3
import pymysql

# MySQL                                                                                                                 
host = 'mtcarsdb.c9qca4k6aw1y.us-east-1.rds.amazonaws.com'                                                              
user = "mtcarsUsername"                                                                                                 
password = "mtcars123"                 
database = "MTCars"

# This handler is run every time the Lambda function is invoked
def lambda_handler(event, context):
    # Show the incoming event in the debug log
    print("Event received by Lambda function: " + json.dumps(event, indent=2))

    # Connect to RDS MySQL
    connection = pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )
    try:
        with connection.cursor() as cursor:
            # Query for a specific model of car
            car_model = event['car_model']
            car_year = event['car_year']

            cursor.execute(f"SELECT * FROM {database} WHERE NAME = {car_model} AND ANO = {car_year}")
            result = cursor.fetchone()
            
            if result:
                # Construct message to be sent
                message = f"A {car_model} {car_year} is available in the inventory. Hurry up and get it!"
                
                # Connect to SNS
                sns = boto3.client('sns')
                alertTopic = 'CarAvailable'
                snsTopicArn = [t['TopicArn'] for t in sns.list_topics()['Topics'] if t['TopicArn'].lower().endswith(':' + alertTopic.lower())][0]
                
                # Send message to SNS
                sns.publish(
                    TopicArn=snsTopicArn,
                    Message=message,
                    Subject='Car Availability Alert!',
                    MessageStructure='raw'
                )
            else:
                print(f"The car {car_model} {car_year} is not available.")
    except KeyError as e:
        print(f"Key error: {e}")
        return {
            'statusCode': 400,
            'body': json.dumps(f"Missing parameter: {str(e)}")
        }
    except Exception as e:
        print(f"An error occurred: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
    finally:
        connection.close()
    return {
        'statusCode': 200,
        'body': json.dumps('Function ran without errors.')
    }